//go:build ios && cgo

package main

// #include "bridge.h"
import "C"

import (
	"core"
	"encoding/json"
	"sync"
	"unsafe"
)

func main() {}

func takeString(value *C.char) string {
	if value == nil {
		return ""
	}
	defer C.free_string(value)
	return C.GoString(value)
}

func answer(callback unsafe.Pointer, data []byte) {
	value := C.CString(string(data))
	defer C.free(unsafe.Pointer(value))
	C.result(callback, value)
}

//export invokeMethod
func invokeMethod(callback unsafe.Pointer, params *C.char) {
	core.InvokeMethod(takeString(params), func(data []byte) {
		defer C.release_object(callback)
		answer(callback, data)
	})
}

//export quickSetup
func quickSetup(callback unsafe.Pointer, initParams, setupParams *C.char) {
	core.QuickSetup(takeString(initParams), takeString(setupParams), func(message string) {
		defer C.release_object(callback)
		answer(callback, []byte(message))
	})
}

var callbackMu sync.Mutex
var eventCallback unsafe.Pointer

//export setEventListener
func setEventListener(callback unsafe.Pointer) {
	callbackMu.Lock()
	defer callbackMu.Unlock()
	previous := eventCallback
	if callback == nil {
		core.SetEventListener(nil)
	} else {
		core.SetEventListener(func(data []byte) {
			retained := C.retain_object(callback)
			if retained != nil {
				defer C.release_object(retained)
				answer(retained, data)
			}
		})
	}
	eventCallback = callback
	if previous != nil {
		C.release_object(previous)
	}
}

type tunOptions struct {
	Stack                string `json:"stack"`
	Address              string `json:"address"`
	DNS                  string `json:"dns"`
	MTU                  uint32 `json:"mtu"`
	CongestionController string `json:"congestionController"`
}

type tunnelCallbacks struct{}

func (tunnelCallbacks) Protect(int) bool                   { return true }
func (tunnelCallbacks) ResolveUid(int, string, string) int { return -1 }
func (tunnelCallbacks) ResolvePackage(int) string          { return "" }

//export startTUN
func startTUN(callback unsafe.Pointer, fd C.int, rawOptions *C.char) bool {
	if callback != nil {
		defer C.release_object(callback)
	}
	var options tunOptions
	if json.Unmarshal([]byte(takeString(rawOptions)), &options) != nil {
		return false
	}
	settings, err := json.Marshal(map[string]any{
		"mtu":                   options.MTU,
		"congestion-controller": options.CongestionController,
	})
	if err != nil {
		return false
	}
	return core.StartTun(tunnelCallbacks{}, int(fd), options.Stack, options.Address, options.DNS, string(settings))
}

//export stopTun
func stopTun() { core.StopTun() }

//export startListener
func startListener() { core.StartListener() }

//export stopListener
func stopListener() { core.StopListener() }

//export getTraffic
func getTraffic(proxyOnly bool) *C.char { return C.CString(core.GetTraffic(proxyOnly)) }

//export getTotalTraffic
func getTotalTraffic(proxyOnly bool) *C.char { return C.CString(core.GetTotalTraffic(proxyOnly)) }
