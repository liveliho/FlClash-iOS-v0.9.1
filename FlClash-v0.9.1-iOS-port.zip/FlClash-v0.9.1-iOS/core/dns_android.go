//go:build android

package core

import "github.com/metacubex/mihomo/dns"

func updatePlatformSystemDNS(addresses []string) {
	dns.UpdateSystemDNS(addresses)
	dns.FlushCacheWithDefaultResolver()
}
