//go:build ios

package core

import "github.com/metacubex/mihomo/component/resolver"

func updatePlatformSystemDNS(_ []string) {
	// NetworkExtension owns DNS settings; invalidate pooled core resolvers on changes.
	resolver.ClearCache()
	resolver.ResetConnection()
}
