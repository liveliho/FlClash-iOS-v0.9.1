import 'dart:async';
import 'dart:convert';

import 'package:fl_clash/common/common.dart';
import 'package:fl_clash/core/event.dart';
import 'package:fl_clash/core/method.dart';
import 'package:fl_clash/core/spill.dart';
import 'package:fl_clash/enum/enum.dart';
import 'package:fl_clash/models/models.dart';
import 'package:fl_clash/providers/providers.dart';
import 'package:fl_clash/state.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

final _utf8JsonDecoder = utf8.decoder.fuse(json.decoder);

Object? _decodeUtf8Json(Uint8List data) => _utf8JsonDecoder.convert(data);

Map<String, Object?> _decodeResponseOf((Uint8List, CoreMethod) request) {
  final (data, method) = request;
  final decoded = _decodeUtf8Json(data);
  return withResultModel(method, Map<String, Object?>.from(decoded as Map));
}

Future<Map<String, Object?>> _decodeResponse(
  Uint8List data,
  CoreMethod method,
) async {
  if (data.length < 51200) {
    return _decodeResponseOf((data, method));
  }
  return compute(_decodeResponseOf, (data, method));
}

abstract mixin class ServiceListener {
  void onServiceEvent(CoreEvent event) {}

  void onServiceStopped() {}
}

enum TunnelState { pending, connected, disconnected }

class Service {
  static Service? _instance;
  late MethodChannel methodChannel;
  final bool _isIOS;
  static const _coreChannel = MethodChannel('$packageName/core');

  final ObserverList<ServiceListener> _listeners =
      ObserverList<ServiceListener>();

  int _commandRevision = 0;
  bool _startRequested = false;
  TunnelState _tunnelState = TunnelState.pending;
  Completer<void> _tunnelChange = Completer<void>();
  Map<String, dynamic>? _iosSetupParams;

  factory Service() {
    _instance ??= Service._internal();
    return _instance!;
  }

  Service._internal() : _isIOS = system.isIOS {
    _bindChannel();
  }

  @visibleForTesting
  Service.scoped({required bool isIOS}) : _isIOS = isIOS {
    _bindChannel();
  }

  void _bindChannel() {
    methodChannel = const MethodChannel('$packageName/service');
    methodChannel.setMethodCallHandler((call) async {
      switch (call.method) {
        case 'tunnelState':
          _tunnelState = TunnelState.values.byName(call.arguments as String);
          _tunnelChange.complete();
          _tunnelChange = Completer<void>();
          break;
        case 'event':
          final methodCall = CoreMethodCall.fromJson(
            Map<String, Object?>.from(
              _decodeUtf8Json(
                call.arguments is String
                    ? Uint8List.fromList(utf8.encode(call.arguments as String))
                    : call.arguments as Uint8List,
              ) as Map,
            ),
          );
          for (final event in coreEventsFromData(methodCall.arguments)) {
            _dispatch(
              'Core event ${event.type.name}',
              (listener) => listener.onServiceEvent(event),
            );
          }
          break;
        case 'stopped':
          // A report stamped before the newest command no longer describes it.
          if (call.arguments != _commandRevision || !_startRequested) {
            break;
          }
          _startRequested = false;
          _dispatch('stop report', (listener) => listener.onServiceStopped());
          break;
        default:
          throw MissingPluginException();
      }
    });
  }

  Future<CoreMethodResponse?> invokeMethod(CoreMethodCall call) async {
    if (_isIOS) {
      final previousParams = _iosSetupParams;
      if (call.method == CoreMethod.setupConfig) {
        _iosSetupParams = Map<String, dynamic>.from(call.arguments as Map);
      }
      final encoded = await methodChannel.invokeMethod<String>(
        'invokeMethod',
        json.encode(call),
      );
      if (encoded == null) return null;
      final response = await resolveSpilledResponse(
        CoreMethodResponse.fromJson(
          await _decodeResponse(
            Uint8List.fromList(utf8.encode(encoded)),
            call.method,
          ),
        ),
        method: call.method,
      );
      if (call.method == CoreMethod.setupConfig &&
          (response.error != null || response.result != '')) {
        _iosSetupParams = previousParams;
      }
      return response;
    }
    final data = await _coreChannel.invokeMethod<Uint8List>(
      'invokeMethod',
      json.encode(call),
    );
    if (data == null) {
      return null;
    }
    return resolveSpilledResponse(
      CoreMethodResponse.fromJson(await _decodeResponse(data, call.method)),
      method: call.method,
    );
  }

  void _dispatch(String label, void Function(ServiceListener) deliver) {
    for (final listener in List.of(_listeners)) {
      try {
        deliver(listener);
      } catch (error) {
        commonPrint.log(
          'Unable to dispatch Android $label: $error',
          logLevel: LogLevel.error,
        );
      }
    }
  }

  Future<bool> start([SharedState? state]) async {
    _startRequested = true;
    if (_isIOS) {
      if (state == null) return false;
      final revision = ++_commandRevision;
      _tunnelState = TunnelState.pending;
      final accepted =
          await methodChannel.invokeMethod<bool>(
            'start',
            _encodeSharedState(state),
          ) ??
          false;
      final connected =
          accepted && await _waitForTunnel(TunnelState.connected, revision);
      if (!connected && revision == _commandRevision) {
        await stop();
      }
      return connected;
    }
    return await methodChannel.invokeMethod<bool>(
          'start',
          ++_commandRevision,
        ) ??
        false;
  }

  Future<bool> stop() async {
    _startRequested = false;
    if (_isIOS) {
      final revision = ++_commandRevision;
      final accepted = await methodChannel.invokeMethod<bool>('stop') ?? false;
      return accepted &&
          await _waitForTunnel(TunnelState.disconnected, revision);
    }
    return await methodChannel.invokeMethod<bool>('stop', ++_commandRevision) ??
        false;
  }

  Future<String> init() async {
    return await methodChannel.invokeMethod<String>('init') ?? '';
  }

  Future<String> syncState(SharedState state) async {
    return await methodChannel.invokeMethod<String>(
          'syncState',
          _isIOS ? _encodeSharedState(state) : json.encode(state),
        ) ??
        '';
  }

  String _encodeSharedState(SharedState state) {
    final data = Map<String, dynamic>.from(
      json.decode(json.encode(state)) as Map,
    );
    if (_iosSetupParams != null) {
      data['setupParams'] = {
        ..._iosSetupParams!,
        ...?(data['setupParams'] as Map<String, dynamic>?),
      };
    }
    data['excludeSSIDs'] = globalState.container.read(excludeSSIDsProvider);
    return json.encode(data);
  }

  Future<bool> _waitForTunnel(TunnelState target, int revision) async {
    final deadline = DateTime.now().add(const Duration(seconds: 30));
    while (revision == _commandRevision) {
      if (_tunnelState == target) return true;
      if (target == TunnelState.connected &&
          _tunnelState == TunnelState.disconnected) {
        return false;
      }
      final remaining = deadline.difference(DateTime.now());
      if (remaining <= Duration.zero) return false;
      try {
        await _tunnelChange.future.timeout(remaining);
      } on TimeoutException {
        return false;
      }
    }
    return false;
  }

  Future<bool> shutdown() async {
    return await methodChannel.invokeMethod<bool>('shutdown') ?? true;
  }

  Future<DateTime?> getRunTime() async {
    final ms = await methodChannel.invokeMethod<int>('getRunTime') ?? 0;
    if (ms == 0) {
      return null;
    }
    return DateTime.fromMillisecondsSinceEpoch(ms);
  }

  bool get hasListeners {
    return _listeners.isNotEmpty;
  }

  void addListener(ServiceListener listener) {
    _listeners.add(listener);
  }

  void removeListener(ServiceListener listener) {
    _listeners.remove(listener);
  }
}

Service? get service => system.isMobile ? Service() : null;
