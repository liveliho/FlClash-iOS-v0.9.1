# FlClash v0.9.1 iOS 移植工程

## 当前状态

这是原版 v0.9.1 上的 iOS 移植候选工程，尚未完成 macOS 编译、苹果签名及真机联网验收。
不能把这个源码包当作可安装 IPA，也不能把代码检查通过当作代理功能已经验证。

- 原版基线：`chen08209/FlClash` 的 `v0.9.1`，提交 `8d4f9744948751f1273fe871e1d05276fac09b0e`。
- 原版核心子模块：`chen08209/Clash.Meta`，提交 `8380d0e7462f061a964323e9bf3129a236fcc5d5`。
- `lib/views`、`lib/pages`、`lib/ui` 和 `shaders` 中的 175 个文件逐字节保持原版。
- iOS 原生工程和 SSID 插件移植自 GPL-3.0 项目 `chenx-dust/FlClash-Patched`，
  参考提交 `1a9c6acbf7f77b30090e9c6084b0dd224ed48cfb`。这不是该社区分支的官方发行包。
- 没有复制社区分支的 Dart 页面，也没有替换原版 mihomo 核心。

## 实现内容

主应用使用原版 Flutter 界面。独立的 Network Extension 通过 `NEPacketTunnelProvider` 接管流量。
`core/cmd/ios` 将原版 Go 导出的移动 API 编译成静态库，分别链接进主应用和扩展；
扩展使用带软内存预算的构建。原版 Android gomobile 和桌面进程入口继续保留。

主应用和扩展通过同一个 App Group 访问订阅、配置、规则、资源及大响应临时文件。
Swift 消息路由适配 v0.9.1 的 `startLog`、`stopLog`、`watchRoute` 协议。
Flutter 服务兼容 iOS 字符串消息，同时保留 Android 的字节消息及大响应文件处理。
配置的 base/overlay 会随隧道启动传入；连接操作等待系统反馈的已连接状态。

这次没有声称 Android 的逐应用访问控制、进程匹配及桌面权限管理能在普通 iOS 上等价使用。
现有 iOS 系统接口限制仍然适用。后台自动更新、大订阅内存占用和各协议的实际表现需真机验收。

## 已执行的检查

- `CGO_ENABLED=0 go test .`：通过，覆盖原版 Go 核心回归测试。
- 新增和改动 Dart 文件：`dart format` 完成，能解析语法。
- C 桥接：`gcc -Wall -Wextra -fsyntax-only core/cmd/ios/bridge.c` 通过。
- Python 构建脚本语法、shell 脚本语法、iOS XML property list 和 Rust TOML 解析：通过。
- 上述 175 个 UI 文件与 v0.9.1 的逐字节比较：通过。

尚未执行成功：`flutter pub get`、`flutter analyze`、Flutter 桥接测试、Provider 生成、
Rust iOS 构建、Swift/Xcode 编译、IPA 导出、签名和真机验收。

本地 Flutter 工具启动时尝试访问 `169.254.169.254` 云元数据地址，被自动审批拦截，
因此没有继续运行该启动流程。没有使用这种元数据访问作为构建依赖。
Linux 的 `GOOS=ios CGO_ENABLED=0 go vet` 也因 iOS 要求 cgo 外部链接而未通过，
它不是对 iOS 实现的成功编译检查。

## 在云端构建

无需本地 Mac，但需要一个允许 GitHub Actions 使用 macOS runner 的可写仓库。
当前会话的 GitHub 连接没有返回可访问仓库，所以尚未创建远端分支或启动云构建。

推荐将原版项目 fork 到自己的账号，应用随包提供的 `ios-v0.9.1.patch`，推送至 `ios/v0.9.1` 分支。
如果使用完整源码压缩包导入新仓库，保留包内 `.github` 目录和已固定版本的核心源码。

在 Actions 中运行 **iOS v0.9.1 port** 工作流。
它固定 Flutter 3.47.6、Go 1.27.0 和 macOS 26 runner；Rust 使用原版锁定版本。
流程依次解析依赖、生成 Provider、分析 Dart、执行 Go 和 Flutter 回归测试，再编译和打包。
任何一步失败都不会报告为成功构建，需按日志继续修复。

成功后的 artifact 名称为 `FlClash-v0.9.1-iOS-unsigned`，内含：

- `FlClash-0.9.1-ios-arm64-unsigned.ipa`
- IPA 的 SHA-256 校验文件
- `ios-build-report.json`，包括源码基线、包标识和尚未进行真机测试的状态

有 macOS/Xcode 环境时，也可以在仓库根目录运行：

```bash
bash tool/ios/build_unsigned.sh
```

工程当前仅面向 arm64 真机，主应用和隧道扩展最低 iOS 15，附带 Widget 最低 iOS 18。
默认 App ID 为 `com.follow.clash.ios`；签名时应换成开发者自己名下的唯一标识。

## 签名和验收

云端未签名 IPA 带的是用于后续重签名的临时 ad-hoc 签名，不能直接安装使用。
为主应用、`.NECore` 扩展和 `.Widget` 配置匹配的签名和描述文件，
使用同一个 `group.<主应用BundleID>` App Group；主应用和 VPN 扩展需 Network Extension 权限。
主应用当前还声明了 Wi-Fi 信息权限。不要通过删除 VPN 扩展或权限来换取安装成功。

先在真机完成以下验收，再决定是否日常使用：

1. 订阅链接和本地 YAML 导入、资源更新、配置切换。
2. 使用自己控制的有效节点测试实际 IP 出口、TCP、UDP、DNS 和规则分流。
3. 检查原版节点选择、测速、连接列表、请求、DNS 查询和日志界面。
4. 锁屏及退到后台后持续联网；Wi-Fi/蜂窝切换、停止、重复快速启停及系统撤销 VPN 权限。
5. 断线、错误订阅、不可达节点、大规则集及低内存情况下，界面正确反馈失败且手机可恢复网络。
6. 开启 IPv6 时单独检查 IPv6 出口及 DNS；未开启时确认是否存在意外绕行。

在这些步骤完成之前，不提供“全部功能可用”的承诺。
